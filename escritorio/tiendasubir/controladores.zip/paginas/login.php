<form action="./controladores/controladorUsuarios.php" method="post">
<table>
    <input type="hidden" name="opusuario" value="1">
    <tr>
        <td>
            Nombre de usuario:
        </td>
    <tr>
        <td>
            <input type="text" name="usuario">
        </td>
    </tr>
        
    <tr> <td>
            Contraseña:
        </td>
    </tr>
        <td>
            <input type="password" name="clave">
        </td>
        <tr>
            <td>
            <input type="submit" value="ingresar">
        </td>
        </tr>
    </tr>
</table>
</form>