<?php
session_destroy();
header("location:http://www.impuso2015.tk");

