<?php

require_once __DIR__.'/../../modelo/vendor/autoload.php';

require_once __DIR__.'/../../modelo/generated-conf/config.php';
